%  RAINFALL-RUNOFF MODEL (GR2M WITH 3 PARAMETERS) 
%BY TARIK BENKACI (1998-2017) % and N. DECHEMI 
%in the Optim Models there is: GR2M Conceptual model with SCE-UA Optimisation method (Duan et al., 1992, 1993) 
%after many epoch of optimisation Sce-ua Algorithm displays the %best parameters of GR2M model.
% OPTIMISATION IS SCE-UA  (DUAN et al. ): 
%1-Duan,  Q., Sorooshian, S. and Gupta, V.K., 1993. Shuffled complex evolution approach for 
%effective and efficient global minimization. J. Optimiz. Theory Appl. 76(3), 501�521.
%2-Wei Chu, Xiaogang Gao, Soroosh Sorooshian A new evolutionary search strategy for global 
%optimization of high-dimensional problems Information Sciences - 2011
 %GR2M References
%2-Mouelhi, Safouane. 2003. �Vers Une Cha�ne Coh�rente de Mod�les Pluie-D�bit Conceptuels Globaux Aux Pas de Temps 
%Pluriannuel, Annuel, Mensuel et Journalier.� PhD thesis, Paris, ENGREF. 
%3-Mouelhi, S., C. Michel, C. Perrin, and V. Andr�assian (2006), Stepwise development of 
%a two-parameter monthly water balance model, J. Hydrol., 318, 200-214, doi:10.1016/j.jhydrol.2005.1006.1014.
clear all;
Optim_GR2M
% thus the code Run optimisation Process to found best parameters of
% Conceptual GR2M model, with 3 parameters
%after optimisation the model displays and save the results in GR2M.xls results
%and RESULTS Text file
%Finally after optimisation the model can simulate new runoff values with
%GR2M_SIM
% Good Modelling


