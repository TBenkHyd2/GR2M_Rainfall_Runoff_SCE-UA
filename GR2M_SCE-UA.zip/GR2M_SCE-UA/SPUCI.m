%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Code of SPI  Wei Chu, Xiaogang Gao, Soroosh Sorooshian 
%1-Duan,  Q., Sorooshian, S. and Gupta, V.K., 1993. Shuffled complex evolution approach for effective and efficient global minimization. J. Optimiz. Theory Appl. 76(3), 501�521.
%2-Wei Chu, Xiaogang Gao, Soroosh Sorooshian A new evolutionary search strategy for global optimization of high-dimensional problems Information Sciences - 2011


function [bestx,bestf] = SPUCI(x0,bl,bu,maxn,kstop,pcento,peps,ngs,iseed,iniflg)

% This is the Matlab code implementing the SP-UCI algorithm,written by Dr.
% Wei Chu, 08/2012, based on the SCE Matlab codes written by Dr. Q. Duan
% 9/2004.
% 
% If you have any questions or comments,Please contact Dr. Wei Chu at
% wchu2@uci.edu
% 
% This algorithm has been published in Infomration Sciences and shoud be
% cited as:

%   Wei	Chu,	X. Gao and S. Sorooshian,(2011), A new evolutionary search
%   strategy for global optimization of high-dimensional Problems,
%   Information Sciences, doi:10.1016/j.ins. 2011.06.024.
%
%
% Definition of input variables:
%  x0 = the initial parameter array at the start;
%     = the optimized parameter array at the end;
%  f0 = the objective function value corresponding to the initial parameters
%     = the objective function value corresponding to the optimized parameters
%  bl = the lower bound of the parameters
%  bu = the upper bound of the parameters
%  iseed = the random seed number (for repetetive testing purpose)
%  iniflg = flag for initial parameter array (=1, included it in initial
%           population; otherwise, not included)
%  ngs = number of complexes (sub-populations)
%  maxn = maximum number of function evaluations allowed during optimization
%  kstop = maximum number of evolution loops before convergency
%  percento = the percentage change allowed in kstop loops before
%  convergency

% Definition of outputs
%  bestx = best parameter values at the end of the search.
%  besft = best objective function value at the end of the search.

% Initialization of agorithmic 
nopt=length(x0); %dimentions of the problem
npg=2*nopt+1;%  npg = number of members is a complex
nps=nopt+1;%  nps = number of members in a simplex
nspl=nps;%  nspl = number of evolution steps for each complex before shuffling
npt=npg*ngs;%npt = the total number of members (the population size)

bound = bu-bl;% boundary of the feasible space.

rand('seed',iseed);
randn('seed',iseed);

% Initialization of the populaton
x=zeros(npt,nopt);
for i=1:npt;
    x(i,:)=bl+rand(1,nopt).*bound;
end;

if iniflg==1; x(1,:)=x0; end;

nloop=0;
icall=0;
xf=10000*ones(1,npt);
for i=1:npt;
    xf(i) = Model(x(i,:));
    icall = icall + 1;
end;

% Sort the population in order of increasing function values;
[xf,idx]=sort(xf);
x=x(idx,:);

% Check if the population degeneration occured
[x, xf, icall]=DimRest(x,xf,bl,bu,icall);

% Conduct Gaussian Resampling 
[x, xf, icall]=GauSamp(x,xf,bl,bu,icall);

% Sort the population again and record the best and worst points
[xf,idx]=sort(xf);
x=x(idx,:);
bestx=x(1,:); bestf=xf(1);
worstx=x(npt,:); worstf=xf(npt);

% Computes the normalized geometric range of the parameters
gnrng=exp(mean(log((max(x)-min(x))./bound)));

disp('The Initial Loop: 0');
disp(['BESTF  : ' num2str(bestf)]);
disp(['BESTX  : ' num2str(bestx)]);
disp(['WORSTF : ' num2str(worstf)]);
disp(['WORSTX : ' num2str(worstx)]);
disp(' ');

% Check for convergency;
if icall >= maxn;
    disp('*** OPTIMIZATION SEARCH TERMINATED BECAUSE THE LIMIT');
    disp('ON THE MAXIMUM NUMBER OF TRIALS ');
    disp(maxn);
    disp('HAS BEEN EXCEEDED.  SEARCH WAS STOPPED AT TRIAL NUMBER:');
    disp(icall);
    disp('OF THE INITIAL LOOP!');
end;

if gnrng < peps;
    disp('THE POPULATION HAS CONVERGED TO A PRESPECIFIED SMALL PARAMETER SPACE');
end;


% Begin evolution loops:
criter=[];
criter_change=1e+5;

while icall<maxn && gnrng>peps && criter_change>pcento;
    nloop=nloop+1;
    %%%%%%%%%%%%%%%%%%%%%%%%
    idexx=randperm(npt);
    %%%%%%%%%%%%%%%%%%%%%%%%
    % Loop on complexes (sub-populations);
    for igs = 1: ngs;

        % Partition the population into complexes (sub-populations);
        cx=x(idexx(npg*(igs-1)+1:npg*igs),:);
        cf=xf(idexx(npg*(igs-1)+1:npg*igs));
        [cf,idd]=sort(cf);
        cx=cx(idd,:);
  
        % Check if the population degeneration occured
        [cx, cf, icall]=DimRest(cx,cf,bl,bu,icall);
        
        % Evolve sub-population igs for nspl steps:
        for loop=1:nspl;
            % Select simplex by sampling the complex according to a linear
            % probability distribution
            lcs(1) = 1;
            for k3=2:nps;
                for iter=1:1e9;
                    lpos = 1 + floor(npg+0.5-sqrt((npg+0.5)^2 - npg*(npg+1)*rand));
                    idx=find(lcs(1:k3-1)==lpos); if isempty(idx)&&lpos<npg+1; break; end; %#ok<EFIND>
                end;
                lcs(k3) = lpos;
            end;
            lcs=sort(lcs);

            % Construct the simplex:
            s=cx(lcs,:); sf = cf(lcs);

            [s,sf,icall]=MCCE(s,sf,bl,bu,icall);

            % Replace the simplex into the complex;
            cx(lcs,:) = s;
            cf(lcs) = sf;

            % Sort the complex;
            [cf,idx] = sort(cf); cx=cx(idx,:);
            clear lcs

            % End of Inner Loop for Competitive Evolution of Simplexes
        end;

        % Conduct Gaussian Resampling 
        [cx, cf, icall]=GauSamp(cx,cf,bl,bu,icall);
        
        % Replace the complex back into the population;
        x(idexx(npg*(igs-1)+1:npg*igs),:)=cx;
        xf(idexx(npg*(igs-1)+1:npg*igs))=cf;

    % End of Loop on Complex Evolution;
    end;

    % Shuffle the complexes, and record the best and worst points;
    [xf,idx] = sort(xf); x=x(idx,:);
    bestx=x(1,:); bestf=xf(1);
    worstx=x(npt,:); worstf=xf(npt); 
 
    % Computes the normalized geometric range of the parameters
    gnrng=exp(mean(log((max(x)-min(x))./bound)));

    disp(['Evolution Loop: ' num2str(nloop) '  - Trial - ' num2str(icall)]);
    disp(['BESTF  : ' num2str(bestf)]);
    disp(['BESTX  : ' num2str(bestx)]);
    disp(['WORSTF : ' num2str(worstf)]);
    disp(['WORSTX : ' num2str(worstx)]);
    disp(' ');

    % Check for convergency;
    if icall >= maxn;
        disp('*** OPTIMIZATION SEARCH TERMINATED BECAUSE THE LIMIT');
        disp(['ON THE MAXIMUM NUMBER OF TRIALS ' num2str(maxn) ' HAS BEEN EXCEEDED!']);
    end;

    if gnrng < peps;
        disp('THE POPULATION HAS CONVERGED TO A PRESPECIFIED SMALL PARAMETER SPACE');
    end;

    criter=[criter;bestf]; %#ok<AGROW>
    if (nloop >= kstop);
        criter_change=abs(criter(nloop)-criter(nloop-kstop+1))*100;
        criter_change=criter_change/mean(abs(criter(nloop-kstop+1:nloop)));
        if criter_change < pcento;
            disp(['THE BEST POINT HAS IMPROVED IN LAST ' num2str(kstop) ' LOOPS BY ', ...
                'LESS THAN THE THRESHOLD ' num2str(pcento) '%']);
            disp('CONVERGENCY HAS ACHIEVED BASED ON OBJECTIVE FUNCTION CRITERIA!!!')
        end;
    end;

    % End of the Outer Loops
end;

disp(['SEARCH WAS STOPPED AT TRIAL NUMBER: ' num2str(icall)]);
disp(['NORMALIZED GEOMETRIC RANGE = ' num2str(gnrng)]);
disp(['THE BEST POINT HAS IMPROVED IN LAST ' num2str(kstop) ' LOOPS BY ', ...
    num2str(criter_change) '%']);

return;
